
-- Erika Mendes Rocha RM:03221023 data:07/03/2022 - profª Célia Taniwaki --

create database Atleta1;
use Atleta1;
create table Atleta1 (
idAtleta int primary key,
nome varchar (40),
modalidade varchar (40),
qtdMedalha int
);

-- Inserir dados na tabela, procurando colocar mais de um atleta para cada modalidade:
insert into Atleta1 values (210248, 'Isaquias Queiroz', 'Canoagem', 4),
						   (210203, 'César Cielo', 'Natação', 3),
                           (210215, 'Mayra Aguiar', 'Judô', 3),
                           (210228, 'Robert Scheidt', 'Vela', 5),
                           (210274, 'Gustavo Borges', 'Natação', 4),
                           (210231, 'Marcelo Ferreira', 'Vela', 3),
                           (210265, 'Torben Grael', 'Vela', 5),
                           (210202, 'Jaqueline Carvalho', 'Vôlei', 2),
                           (210259, 'Sheilla Castro', 'Vôlei', 2);
                           
-- Exibir os dados de todos os atletas cujo idAtleta seja diferente de um determinado valor:
select * from Atleta1 where idAtleta <> 210215;

-- Exibir os dados da tabela ordenados pela modalidade:
select idAtleta, nome, qtdMedalha from Atleta1 where modalidade in ('Canoagem',
                                                                    'Natação', 
                                                                    'Judô', 
                                                                    'Vela',
                                                                    'Vôlei'); 
                                                                    
-- Exibir os dados da tabela, ordenados pela quantidade de medalhas, em ordem decrescente:
select idAtleta, nome, modalidade from Atleta1 order by qtdMedalha desc;

-- Exibir os dados da tabela, dos atletas cujo nome contenha uma determinada letra:
select * from Atleta1 where nome like '%y%';

-- Exibir os dados da tabela, dos atletas cujo nome comece com uma determinada letra:
select * from Atleta1 where nome like 's%';

-- Exibir os dados da tabela, dos atletas cujo nome termine com uma determinada letra:
select * from Atleta1 where nome like '%o';

-- Exibir os dados da tabela, dos atletas cujo nome tenha uma determinada letra como penúltima:
select * from Atleta1 where nome like '%e_';

-- Altere a quantidade de medalhas de um atleta:
update Atleta1 set qtdMedalha = 2 where idAtleta = 210203;

-- Altere o nome e a quantidade de medalhas de um atleta;
update Atleta1 set nome = 'Marcelo Costa', qtdMedalha = 5 where idAtleta = 210259;

-- Exclua um atleta:
delete from Atleta1 where idAtleta = 210259;

-- Eliminar a tabela:
drop table Atleta1;
 

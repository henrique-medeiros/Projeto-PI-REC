
-- Erika Mendes Rocha RM:03221023 data:07/03/2022 - profª Célia Taniwaki --

create database Musica1;
use Musica1;
create table Musica1 (idMusica int primary key,
					  titulo varchar (40),
                      artista varchar (40), 
                      genero varchar (40)); 
                      
-- Procure inserir pelo menos umas 7 músicas;
insert into Musica1 values (001, 'Toda Menina Baiana', 'Gilberto Gil', 'MPB'),
						   (002, 'Dê um Rolê', 'Novos Baianos', 'MPB'),
                           (003, 'Preciso Me Encontrar', 'Cartola', 'Samba'),
                           (004, 'Pela Luz dos Olhos Teus', 'Tom Jobim e Miúcha', 'MPB'),
                           (005, 'Baila Comigo', 'Rita Lee', 'Rock Nacional'),
                           (006, 'Chove Chuva', 'Jorge Ben Jor', 'Samba'),
                           (007, 'Panis Et Circenses', 'Os Mutantes', 'Rock Nacional'),
                           (008, 'Mas, que nada!', 'Jorge Ben Jor', 'Samba');
                           
-- Exibir os dados das músicas cujo idMusica seja diferente de 2 valores, como 2 e 5, por exemplo:
select * from Musica1 where idMusica <>2 and idMusica <>5;

-- Exibir os dados da tabela ordenados pelo título da música:
select idMusica, artista, genero from Musica1 where titulo in ('Toda Menina Baiana',
															   'Dê um Rolê',
                                                               'Preciso Me Encontrar',
                                                               'Pela Luz dos Olhos Teus',
                                                               'Baila Comigo',
                                                               'Chove Chuva',
                                                               'Panis Et Circenses',
                                                               'Mas, que nada!');
                                    
-- Exibir os dados da tabela ordenados pelo artista em ordem decrescente:
select artista, idMusica, genero, titulo from Musica1 order by idMusica desc;

-- Exibir os dados da tabela, das músicas cujo título comece com uma determinada letra:
select * from Musica1 where titulo like 'p%';
 
-- Exibir os dados da tabela, das músicas cujo artista termine com uma determinada letra:
select * from Musica1 where artista like '%s';

-- Exibir os dados da tabela, das músicas cujo gênero tenha como segunda letra uma determinada:
select * from Musica1 where genero like '_p%';

-- Exibir os dados da tabela, das músicas cujo título tenha como penúltima letra uma determinada letra:
select * from Musica1 where titulo like '%a_';

-- Altere o gênero de uma música:
update Musica1 set genero = 'MPB' where idMusica = 006;

-- Altere o nome do artista e o gênero de uma música:
update Musica1 set artista = 'Vinicius de Moraes', genero = 'Bossa Nova' where idMusica = 004;

-- Exclua uma música da tabela:
delete from Musica1 where idMusica = 004;

-- Elimine a tabela;
drop table Musica1;

 
                                    
                                    
                                    
                           

package validacao

import javax.swing.JOptionPane.*

// Para contextualizar, este é um aplicativo escrito em Kotlin para cadastro e autenticação de usuarios em uma Interface
// Grafica (GUI).

fun main() {
    showMessageDialog(null, "Seja bem-vindo!\nGrupo 1 - PI - REC", "Sistema de Cadastro e Autenticação", PLAIN_MESSAGE)
    menu()
}

fun menu() {
    var contador = true
    while (contador) {

        val escolha: String =
            showInputDialog(
                null,
                "- Digite 1 para se logar\r\n- Digite 2 para se cadastrar\r\n- Digite 3 para sair",
                "Menu de Opções",
                QUESTION_MESSAGE
            ).toString()
        if (escolha == "") {
            contador = true
        }
        if (escolha == "1") {
            logar("fernandoBrandao", "12345")
            break
        }
        if (escolha == "2") {
            cadastrar()
            break
        }

        if (escolha == "3") {
            sair()
            break
        }

    }
}

fun sair() {
    showMessageDialog(null, "Programa encerrado!", "Sistema de Cadastro e Autenticação", WARNING_MESSAGE)

}

fun logar(usuario: String, senha: Any) {

    var contador = true
    while (contador) {
        val usuarioInput = showInputDialog(
            null,
            "Usuário\nDigite 3 para sair do programa",
            "Sistema de Login",
            QUESTION_MESSAGE
        )
        if (usuarioInput == "3") {
            sair()
            break
        }
        val senhaInput = showInputDialog(
            null,
            "Senha\nDigite 3 para sair do programa",
            "Sistema de Login",
            QUESTION_MESSAGE
        )
        if (senhaInput == "3") {
            sair()
            break
        }

        val codigo: Int = showConfirmDialog(
            null,
            "Sistema de Login\n> Confirmação de Dados:\n- Nome de usuario: $usuarioInput\n- Senha: $senhaInput"
        )

        if (codigo == 0) {
            if (usuario == usuarioInput) {
                println("Seu usuario foi confirmado com sucesso!")
                if (senha == senhaInput) {
                    println("Sua senha foi confirmada com sucesso!")
                    println("Sistema desbloqueado.")
                    showMessageDialog(null, "Bem-Vindo à REC.", "Sistema de Login", INFORMATION_MESSAGE)

                    break
                } else {
                    showMessageDialog(null, "Senha Incorreta!", "Sistema de Login", ERROR_MESSAGE)
                    println("Confirmação de senha incorreta.")
                    contador = true
                }
            } else {
                showMessageDialog(null, "Este usuário não existe.", "Sistema de Login", ERROR_MESSAGE)
                println("Confirmação de usuario incorreta.")
                contador = true
            }
        }

        if (codigo == 1) {
            menu()
            break
        }
        if (codigo == 2) {
            sair()
            break
        }

    }
}


fun cadastrar() {
    var contador = true
    while (contador) {
        val usuario = showInputDialog(
            null,
            "Digite seu nome de Usuário no campo abaixo\nDigite 3 para sair do programa",
            "Sistema de Cadastro",
            QUESTION_MESSAGE
        )

        if (usuario == "3") {
            sair()
            break
        }
        val nome = showInputDialog(
            null,
            "Digite seu nome e sobrenome no campo abaixo\nDigite 3 para sair do programa",
            "Sistema de Cadastro",
            QUESTION_MESSAGE
        )
        if (nome == "3") {
            sair()
            break
        }
        val email = showInputDialog(
            null,
            "Digite seu E-mail no campo abaixo\nDigite 3 para sair do programa",
            "Sistema de Cadastro",
            QUESTION_MESSAGE
        )
        if (email == "3") {
            sair()
            break
        }
        val senha = showInputDialog(
            null,
            "Digite sua senha no campo abaixo\nDigite 3 para sair do programa",
            "Sistema de Cadastro",
            QUESTION_MESSAGE
        )
        if (senha == "3") {
            sair()
            break
        }
        val confirmaSenha = showInputDialog(
            null,
            "Digite sua senha novamente para confirmação\nDigite 3 para sair do programa",
            "Sistema de Cadastro",
            QUESTION_MESSAGE
        )
        if (confirmaSenha == "3") {
            sair()
            break
        }

        val usuario1 = usuario()

        if (usuario == "" || nome == "" || email == "" || senha == "" || confirmaSenha == "") {
            println("Campos em branco, por gentileza preencher.")
            showMessageDialog(null, "Campos em branco, por gentileza preencher.", "Sistema de Cadastro", ERROR_MESSAGE)
            contador = true
        } else if (senha == confirmaSenha) {
            println("Validações de preenchimento realizadas com sucesso.")
            val codigo: Int = showConfirmDialog(
                null,
                "Sistema de Cadastro\n> Confirmação de Dados:\n- Nome: $nome\n- Nome de usuario: $usuario\n- E-mail: $email\n- Senha: $senha"
            )
            if (codigo == 0) {
                val cadastro = usuario1.cadastrar(nome, usuario, email, senha)
                println(cadastro)
                logar(usuario1.userName[0], usuario1.senhaVetor[0])
                break
            }

            if (codigo == 1) {
                menu()
                break
            }
            if (codigo == 2) {
                sair()
                break
            }

        } else {
            showMessageDialog(null, "Confirmação de senha invalida.", "Sistema de Cadastro", ERROR_MESSAGE)
            println("Confirmação de senha invalida.")
            contador = true
        }

    }

}






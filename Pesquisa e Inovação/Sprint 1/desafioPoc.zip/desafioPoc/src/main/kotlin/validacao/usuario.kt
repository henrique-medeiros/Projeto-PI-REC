package validacao

import javax.swing.JOptionPane.*

class usuario {
    val nomeVetor = mutableListOf<String>()
    val userName = mutableListOf<String>()
    val senhaVetor = mutableListOf<Any>()
    val emailVetor = mutableListOf<String>()

    fun cadastrar(nome: String, usuario: String, email: String, senha: Any): String {
        println("Cadastrando dados no sistema!")
        nomeVetor.add(nome)
        println("- Detalhamento:\nNome: ${nomeVetor[0]}")
        userName.add(usuario)
        println("Usuario: ${userName[0]}")
        emailVetor.add(email)
        println("E-mail: ${emailVetor[0]}")
        senhaVetor.add(senha)
        println("Senha: ${senhaVetor[0]}")
        showMessageDialog(
            null,
            "Usuário cadastrado com sucesso!\n- Nome: ${nomeVetor[0]}\n- Nome de usuario: ${userName[0]}\n- E-mail: ${emailVetor[0]}\n- Senha: ${senhaVetor[0]}",
            "Detalhamento de Cadastro",
            INFORMATION_MESSAGE
        )

        return "Usuário cadastrado com sucesso!"
    }


}